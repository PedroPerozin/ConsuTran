/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scheduler;

import Beans.Operacao;
import java.util.LinkedList;

/**
 *
 * @author jeffersonmantovani
 */
public class Espera {
    
    LinkedList<Operacao> listaEspera;
    
    public Espera(){
        listaEspera = new LinkedList<>();
    }
    
    public void setEspera(Operacao transacao){
        listaEspera.add(transacao);
    }
    
    public Operacao getEspera(Operacao transacao){
        for (Operacao aux : listaEspera) {
            if (aux == transacao)
                return aux;
        }
    return null;
    }
    
}
