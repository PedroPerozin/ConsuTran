/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scheduler;

import static Beans.Bloqueio.EXCLUSIVE;
import static Beans.Bloqueio.SHARED;
import static Beans.Bloqueio.UNLOCKED;
import Beans.Dado;
import Beans.ListaDado;
import Beans.ListaOperacao;
import Beans.Operacao;
import java.util.Iterator;
import java.util.LinkedList;


/**
 *
 * @author jeffersonmantovani
 */
public class Escalonador {
    
    private char status;
    

    public Escalonador(){
        
    }

    public void Escalonador(ListaOperacao listaOperacao, Espera listaEspera){
        
        ListaDado listaDado = new ListaDado();
        
        for(int i=0; i<listaOperacao.getSize(); i++){
            
            if (listaOperacao.getOperacao(i).getStatus() == false){

                if (listaOperacao.getOperacao(i).getOperacao().charAt(0) == 'B'){
                    Dado dado = new Dado(listaOperacao.getOperacao(i));
                    listaDado.setDado(dado);
                }
                else if (listaOperacao.getOperacao(i).getOperacao().charAt(0) == 'R'){
                    for(int j=0; j<listaDado.getSize(); j++){
                        if(listaOperacao.getOperacao(i).getItemDado() == listaDado.getDado(i).getOperacao().getItemDado()
                           && listaDado.getDado(i).getBloqueio() == UNLOCKED){
                            listaDado.getDado(i).setBloqueio(listaDado.getDado(i), SHARED);
                        }
                        else if(listaOperacao.getOperacao(i).getItemDado() == listaDado.getDado(i).getOperacao().getItemDado()
                                && listaDado.getDado(i).getBloqueio() == SHARED){
                            
                        }
                        else if(listaOperacao.getOperacao(i).getItemDado() == listaDado.getDado(i).getOperacao().getItemDado()
                                && listaDado.getDado(i).getBloqueio() == EXCLUSIVE) {
                            listaEspera.setEspera(listaOperacao.getOperacao(i));
                        }
                    }
                }
                
            }
        }
    }
}
        

