/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import static Beans.Bloqueio.UNLOCKED;
import java.util.LinkedList;

/**
 *
 * @author jeffersonmantovani
 */
public class Dado {
    
    
    private Bloqueio bloqueio;
    private Operacao operacao;
    
    public Dado(Operacao operacao){
        this.operacao = operacao;
        this.bloqueio = UNLOCKED;
    }
    
    public void setBloqueio(Dado dado, Bloqueio bloqueio){
        dado.bloqueio = bloqueio;
    }
    
    public Bloqueio getBloqueio(){
        return this.bloqueio;
    }
    
    public Operacao getOperacao(){
        return this.operacao;
    }
    
    
    
}
